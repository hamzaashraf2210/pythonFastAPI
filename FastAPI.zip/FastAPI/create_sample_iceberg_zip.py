import duckdb
import pandas as pd
import os
import shutil
import zipfile

# Create a sample DataFrame
df = pd.DataFrame({
    "id": [1, 2, 3],
    "name": ["Alice", "Bob", "Charlie"],
    "age": [25, 30, 35]
})

# Create a temp folder for the Iceberg table
iceberg_dir = "sample_iceberg_table"
if os.path.exists(iceberg_dir):
    shutil.rmtree(iceberg_dir)
os.makedirs(iceberg_dir, exist_ok=True)

# Create the Iceberg table using DuckDB
con = duckdb.connect()
con.execute(f"INSTALL iceberg; LOAD iceberg;")
con.execute(f"""
    CREATE TABLE sample_iceberg_table 
    (id INTEGER, name STRING, age INTEGER)
    USING iceberg
    LOCATION '{iceberg_dir}';
""")

# Insert the data
con.register("df", df)
con.execute("INSERT INTO sample_iceberg_table SELECT * FROM df")

# Zip the Iceberg table directory
zip_filename = "sample_iceberg_table.zip"
with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(iceberg_dir):
        for file in files:
            full_path = os.path.join(root, file)
            arcname = os.path.relpath(full_path, start=iceberg_dir)
            zipf.write(full_path, arcname=os.path.join("sample_iceberg_table", arcname))

print(f"✅ Created and zipped Iceberg table: {zip_filename}")